﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laskutesti1
{
    class Program
    {
        static void Main(string[] args)
        {
            //-----------------LÄPÄISY % -TESTI-------------------
            /* List<pros> prose = new List<pros>
             {
                 new pros {index=1,tulos = 650},
                 new pros {index=2,tulos = 310},
                 new pros {index=3,tulos = 255},
                 new pros {index=6,tulos = 502},
                 new pros {index=8,tulos = 300}
             };

             //double?[] t = new double?[] {500,450,100,300};
             List<pros> tulos = Laskut.lapaisyProsentti(prose, 2037);
             Console.WriteLine("Onnistuiko ?");
             for(int i = 0; i < tulos.Count; i++)
             {
                 Console.WriteLine("INDEX: "+tulos[i].index+", LÄPÄISY %: " + tulos[i].tulos);
             }
             Console.ReadLine();*/
            //-----------------------------------------------------


            //---------------SEULALLE JÄI % -TESTI------------------
            /* Console.WriteLine("Seulalle jäi: " + Laskut.seulalleJai(1480,2305));
             Console.Read();*/
            //-----------------------------------------------------


            //---------------PUNNITUS YHTEENSÄ -TESTI--------------
            /*double[] syotetyt = new double[19] {205,325,312,46,452,12,432,52,33,2,23,51,21,18,2,4,1,0.4,0.93};

            Console.WriteLine("Yhteispaino: "+Laskut.punnitusYhteensa(syotetyt));
            Console.Read();*/
            //-----------------------------------------------------


            //------------------KOSTEUS % -TESTI-------------------
            /*Console.WriteLine("Kosteusprosentti: " + Laskut.kosteusprosentti(1992.3,2300));
            Console.Read();*/
            //-----------------------------------------------------

        }
    }
}
