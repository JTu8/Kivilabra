﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laskutesti1
{
    public class pros
    {
        public double? tulos { get; set; }
        public int? index { get; set; }
    }
}
